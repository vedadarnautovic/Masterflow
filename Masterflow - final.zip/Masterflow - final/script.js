'use strict';

const account1 = {
  owner: 'Vedad Arnautovic',
  pin: 1111,
};

const accounts = [account1];

const labelWelcome = document.querySelector('.welcome');

const containerApp = document.querySelector('.app');
const containerMovements = document.querySelector('.movements');

const btnLogin = document.querySelector('.login__btn');
const btnTransfer = document.querySelector('.form__btn--transfer');
const btnLoan = document.querySelector('.form__btn--loan');
const btnClose = document.querySelector('.form__btn--close');
const btnSort = document.querySelector('.btn--sort');

const inputLoginUsername = document.querySelector('.login__input--user');
const inputLoginPin = document.querySelector('.login__input--pin');
const inputCloseUsername = document.querySelector('.form__input--user');
const inputClosePin = document.querySelector('.form__input--pin');

const createUsernames = function (accs) {
  accs.forEach(function (acc) {
    acc.username = acc.owner
      .toLowerCase()
      .split(' ')
      .map(name => name[0])
      .join('');
  });
};
createUsernames(accounts);

let slika1 = document.querySelector('.first');
let slika2 = document.querySelector('.second');
let slika3 = document.querySelector('.third');

let currentAccount;

btnLogin.addEventListener('click', function (e) {
  e.preventDefault();

  currentAccount = accounts.find(
    acc => acc.username === inputLoginUsername.value
  );
  console.log(currentAccount);

  if (currentAccount?.pin === Number(inputLoginPin.value)) {
    labelWelcome.textContent = `Welcome back, ${
      currentAccount.owner.split(' ')[0]
    }`;
    containerApp.style.opacity = 100;

    inputLoginUsername.value = inputLoginPin.value = '';
    inputLoginPin.blur();
  }
});

const spec = document.querySelector('.mala');
const casual = document.querySelector('.but');
const job = document.querySelector('.peach');
const firstImg = document.querySelector('.first');
const secondImg = document.querySelector('.second');
const thirdImg = document.querySelector('.third');
const backBtn = document.querySelector('.back');

spec.addEventListener('click', function () {
  firstImg.classList.toggle('hidden');
  spec.classList.toggle('hidden');
  casual.classList.toggle('hidden');
  job.classList.toggle('hidden');
});

casual.addEventListener('click', function () {
  secondImg.classList.toggle('hidden');
  spec.classList.toggle('hidden');
  casual.classList.toggle('hidden');
  job.classList.toggle('hidden');
});

job.addEventListener('click', function () {
  thirdImg.classList.toggle('hidden');
  spec.classList.toggle('hidden');
  casual.classList.toggle('hidden');
  job.classList.toggle('hidden');
});

backBtn.addEventListener('click', function () {
  firstImg.classList.add('hidden');
  secondImg.classList.add('hidden');
  thirdImg.classList.add('hidden');
  spec.classList.toggle('hidden');
  casual.classList.toggle('hidden');
  job.classList.toggle('hidden');
});

const prvibtn = document.querySelector('.prvibtn');
const prviBtn = document.querySelector('.prva');
prvibtn.addEventListener('click', function () {
  prviBtn.classList.toggle('hidden');
});

const barCode = document.querySelector('.barcode');

btnClose.addEventListener('click', function () {
  barCode.classList.toggle('hidden');
});

let sorted = false;
